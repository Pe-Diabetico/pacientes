// --- COLE O LINK DA SUA PLANILHA PUBLICADA AQUI ---
// (Obtido no Passo 2)
const CSV_URL = 'COLE_SEU_LINK_CSV_PUBLICADO_AQUI';

// --- dados de configuração (pesos simples para demo) ---
const WEIGHTS = {
  tempo_diabetes: 0.12,
  hba1c: 0.12,
  neuropatia: 0.22,
  dap: 0.15,
  ppp: 0.12,
  ptt: 0.06,
  temp_ass: 0.14,
  historico_ulc: 0.12
};

// Estado global para armazenar os pacientes e o índice atual
const state = {
  paciente: null,
  allPatients: [],
  currentIndex: 0
};

function norm(x, min, max) {
  return Math.min(1, Math.max(0, (x - min) / (max - min)));
}

// Nova função para carregar dados da planilha
async function loadData() {
  try {
    const response = await fetch(CSV_URL);
    if (!response.ok) {
      throw new Error(`Erro ao buscar CSV: ${response.statusText}`);
    }
    const csvText = await response.text();
    state.allPatients = parseCSV(csvText);
    
    if (state.allPatients.length > 0) {
      showPatient(state.currentIndex);
    } else {
      console.error("Nenhum paciente encontrado na planilha.");
    }
  } catch (error) {
    console.error("Falha ao carregar ou analisar os dados:", error);
    alert("Não foi possível carregar os dados da planilha. Verifique o link no CSV_URL e se a planilha está publicada.");
  }
}

// Nova função para analisar o texto CSV
function parseCSV(text) {
  const lines = text.split('\n').filter(line => line.trim() !== ''); // Filtra linhas vazias
  const headers = lines[0].split(',').map(h => h.trim());

  // Mapeia os nomes das colunas da sua planilha para os nomes internos do script
  const columnMap = {
    nome: headers.indexOf('nome'),
    sobrenome: headers.indexOf('sobrenome'),
    idade: headers.indexOf('idade'),
    sexo: headers.indexOf('sexo'),
    tempo: headers.indexOf('tempo_diabetes_anos'),
    hba1c: headers.indexOf('hba1c_perc'),
    imc: headers.indexOf('imc'),
    neuropatia: headers.indexOf('neuropatia_s_n'),
    deformidade: headers.indexOf('deformidade_s_n'),
    ulc_prev: headers.indexOf('ulcera_previa_s_n'),
    amp_prev: headers.indexOf('amputacao_previa_s_n'),
    dap: headers.indexOf('dap_s_n'),
    has: headers.indexOf('has_s_n'),
    tab: headers.indexOf('tabagismo_s_n'),
    alc: headers.indexOf('alcool_s_n'),
    atividade: headers.indexOf('atividade_fisica_s_n'),
    vel: headers.indexOf('velocidade_marcha_m_s'),
    passos: headers.indexOf('contagem_passos'),
    acc: headers.indexOf('aceleracao_vertical_rms'),
    ori: headers.indexOf('orientacao_pe_graus'),
    ppp_esq: headers.indexOf('pressao_pico_esq_kpa'),
    ppp_dir: headers.indexOf('pressao_pico_dir_kpa'),
    temp_esq: headers.indexOf('temperatura_esq_c'),
    temp_dir: headers.indexOf('temperatura_dir_c')
  };

  const patients = [];
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',');
    
    // Converte 's'/'sim' para true, qualquer outra coisa para false
    const toBool = (val) => val ? (val.trim().toLowerCase() === 's' || val.trim().toLowerCase() === 'sim') : false;
    // Converte para número, tratando valor vazio como 0
    const toNum = (val) => val ? parseFloat(val.trim()) : 0;

    const p = {
      nome: values[columnMap.nome],
      sobrenome: values[columnMap.sobrenome],
      idade: toNum(values[columnMap.idade]),
      sexo: values[columnMap.sexo],
      tempo: toNum(values[columnMap.tempo]),
      hba1c: toNum(values[columnMap.hba1c]),
      imc: toNum(values[columnMap.imc]),
      neuropatia: toBool(values[columnMap.neuropatia]),
      dap: toBool(values[columnMap.dap]),
      deformidade: toBool(values[columnMap.deformidade]),
      ulc_prev: toBool(values[columnMap.ulc_prev]),
      amp_prev: toBool(values[columnMap.amp_prev]),
      has: toBool(values[columnMap.has]),
      tab: toBool(values[columnMap.tab]),
      alc: toBool(values[columnMap.alc]),
      atividade: toBool(values[columnMap.atividade]),
      vel: toNum(values[columnMap.vel]),
      passos: toNum(values[columnMap.passos]),
      acc: toNum(values[columnMap.acc]),
      ori: toNum(values[columnMap.ori]),
      temp_esq: toNum(values[columnMap.temp_esq]),
      temp_dir: toNum(values[columnMap.temp_dir]),
      ppp_esq: toNum(values[columnMap.ppp_esq]),
      ppp_dir: toNum(values[columnMap.ppp_dir])
    };
    patients.push(p);
  }
  return patients;
}

// Funções de navegação
function nextPatient() {
  if (state.allPatients.length === 0) return;
  state.currentIndex = (state.currentIndex + 1) % state.allPatients.length;
  showPatient(state.currentIndex);
}

function prevPatient() {
  if (state.allPatients.length === 0) return;
  state.currentIndex = (state.currentIndex - 1 + state.allPatients.length) % state.allPatients.length;
  showPatient(state.currentIndex);
}

// Define o paciente atual e atualiza a UI
function showPatient(index) {
  state.paciente = state.allPatients[index];
  atualizarUI();
}

// Função original (quase inalterada) que desenha os dados na tela
function atualizarUI() {
  const p = state.paciente;
  
  // Reseta a UI se não houver paciente (estado inicial)
  if (!p) {
    document.getElementById('avatar').textContent = 'CP';
    document.getElementById('p_nome').textContent = 'Nome: —';
    document.getElementById('p_demo').textContent = 'idade — • sexo — • imc —';
    document.getElementById('p_clin').textContent = 'Tempo DM — • HbA1c —';
    
    document.getElementById('etiologia').innerHTML='';
    document.getElementById('habitos').innerHTML='';
    document.getElementById('sensors').innerHTML='';

    const fillOr = (id,val)=>document.getElementById(id).textContent = val===undefined?'—':val;
    ['f_idade','f_sexo','f_imc','f_tempo','f_hba1c','f_vel','f_passos','f_acc','f_ori','f_defo','f_has','f_tab','f_alc','f_atividade','f_ulc','f_amp'].forEach(i=>fillOr(i,'—'));
    ['temp-esq','temp-dir','temp-ass','ppp-esq','ppp-dir'].forEach(i=>document.getElementById(i)&&(document.getElementById(i).textContent='—'));
    document.getElementById('score').textContent='—';
    document.getElementById('score-label').textContent='—';
    document.getElementById('badge-neuro').textContent='Neuropatia: —';
    document.getElementById('badge-dap').textContent='DAP: —';
    document.getElementById('meter-fill').style.width='0%';
    document.getElementById('ppp-bar').style.width='0%';
    return;
  }

  // Preenche o card do paciente
  document.getElementById('avatar').textContent = p.nome ? (p.nome[0]+p.sobrenome[0]) : '??';
  document.getElementById('p_nome').textContent = `Nome: ${p.nome} ${p.sobrenome}`;
  document.getElementById('p_demo').textContent = `idade ${p.idade} • sexo ${p.sexo} • imc ${p.imc}`;
  document.getElementById('p_clin').textContent = `Tempo DM ${p.tempo} anos • HbA1c ${p.hba1c}%`;

  // Limpa e preenche os chips
  const etiologia = document.getElementById('etiologia'); etiologia.innerHTML='';
  const habitos = document.getElementById('habitos'); habitos.innerHTML='';
  const sensors = document.getElementById('sensors'); sensors.innerHTML='';

  // etiologia chips
  etiologia.appendChild(chip('Neuropatia', p.neuropatia));
  etiologia.appendChild(chip('DAP', p.dap));
  etiologia.appendChild(chip('Deformidade', p.deformidade));
  etiologia.appendChild(chip('Úlcera prévia', p.ulc_prev));
  etiologia.appendChild(chip('Amputação prévia', p.amp_prev));

  // habitos
  habitos.appendChild(chip('HAS', p.has));
  habitos.appendChild(chip('Tabagismo', p.tab));
  habitos.appendChild(chip('Álcool', p.alc));
  habitos.appendChild(chip('Atividade física', p.atividade));

  // sensores
  sensors.appendChild(chip(`Velocidade ${p.vel} m/s`, true));
  sensors.appendChild(chip(`Passos ${p.passos}`, true));
  sensors.appendChild(chip(`PPP E ${p.ppp_esq} kPa`, true));
  sensors.appendChild(chip(`PPP D ${p.ppp_dir} kPa`, true));

  // preencher features
  const fillOr = (id,val)=>document.getElementById(id).textContent = val===undefined?'—':val;
  const simNao = (val) => val ? 'Sim' : 'Não';
  
  fillOr('f_idade',p.idade);
  fillOr('f_sexo',p.sexo);
  fillOr('f_imc',p.imc);
  fillOr('f_tempo',p.tempo+' anos');
  fillOr('f_hba1c',p.hba1c+' %');
  fillOr('f_vel',p.vel+' m/s');
  fillOr('f_passos',p.passos);
  fillOr('f_acc',p.acc);
  fillOr('f_ori',p.ori+'°');
  fillOr('f_defo', simNao(p.deformidade));
  fillOr('f_has', simNao(p.has));
  fillOr('f_tab', simNao(p.tab));
  fillOr('f_alc', simNao(p.alc));
  fillOr('f_atividade', simNao(p.atividade));
  fillOr('f_ulc', simNao(p.ulc_prev));
  fillOr('f_amp', simNao(p.amp_prev));

  // Card de temperatura
  document.getElementById('temp-esq').textContent = p.temp_esq;
  document.getElementById('temp-dir').textContent = p.temp_dir;
  const tass = Math.abs((p.temp_esq - p.temp_dir)).toFixed(1);
  document.getElementById('temp-ass').textContent = tass + ' °C';

  // Card de pressão
  document.getElementById('ppp-esq').textContent = p.ppp_esq;
  document.getElementById('ppp-dir').textContent = p.ppp_dir;
  const pppMax = Math.max(p.ppp_esq, p.ppp_dir);
  const pppPct = Math.min(100, Math.round((pppMax / 300) * 100)); // 300 kPa como teto
  document.getElementById('ppp-bar').style.width = pppPct + '%';

  // Badges de Risco
  document.getElementById('badge-neuro').textContent = `Neuropatia: ${simNao(p.neuropatia)}`;
  document.getElementById('badge-dap').textContent = `DAP: ${simNao(p.dap)}`;

  // calcular risco
  const risco = calcularRisco(p);
  mostrarRisco(risco);
}

function chip(text, active) {
  const d = document.createElement('div');
  d.className = 'chip';
  d.textContent = text;
  // Destaca chips "ativos" (condições presentes ou dados de sensor)
  if(active) {
      d.style.background = 'rgba(110, 231, 183, 0.1)'; // Tom verde
      d.style.color = '#6ee7b7';
  }
  return d;
}

function calcularRisco(p) {
  // normalização simples baseada em limites clínicos plausíveis
  const t_norm = norm(p.tempo, 0, 20);
  const h_norm = norm(p.hba1c, 5, 11);
  const neurop = p.neuropatia ? 1 : 0;
  const dap = p.dap ? 1 : 0;
  const ppp = Math.max(p.ppp_esq, p.ppp_dir);
  const ppp_norm = norm(ppp, 100, 300);
  const pt_norm = 0; // placeholder para pressão integral temporal (ptt)
  const tass = Math.abs(p.temp_esq - p.temp_dir);
  const tass_norm = norm(tass, 0, 4); // cutoff aproximado
  const ulc_prev = p.ulc_prev ? 1 : 0;

  let score = 0;
  score += WEIGHTS.tempo_diabetes * t_norm;
  score += WEIGHTS.hba1c * h_norm;
  score += WEIGHTS.neuropatia * neurop;
  score += WEIGHTS.dap * dap;
  score += WEIGHTS.ppp * ppp_norm;
  score += WEIGHTS.ptt * pt_norm;
  score += WEIGHTS.temp_ass * tass_norm;
  score += WEIGHTS.historico_ulc * ulc_prev;

  // map to 0..100
  const scaled = Math.round(Math.min(100, Math.max(0, score * 100)));
  return { raw: score, scaled, components: { t_norm, h_norm, neurop, dap, ppp_norm, tass_norm, ulc_prev } };
}

function mostrarRisco(r) {
  const pct = r.scaled;
  document.getElementById('score').textContent = pct + '%';
  const label = pct < 30 ? 'Baixo' : (pct < 60 ? 'Moderado' : 'Alto');
  document.getElementById('score-label').textContent = label;
  document.getElementById('meter-fill').style.width = pct + '%';

  const fill = document.getElementById('meter-fill');
  if(pct < 30) fill.style.background = 'linear-gradient(90deg,#34d399,#60a5fa)';
  else if(pct < 60) fill.style.background = 'linear-gradient(90deg,#f59e0b,#f97316)';
  else fill.style.background = 'linear-gradient(90deg,#f97316,#ef4444)';
}

// listeners - MODIFICADO
document.addEventListener('DOMContentLoaded', function() {
  // Conecta os novos botões
  const prevBtn = document.getElementById('prev');
  const nextBtn = document.getElementById('next');
  if(prevBtn) prevBtn.addEventListener('click', prevPatient);
  if(nextBtn) nextBtn.addEventListener('click', nextPatient);

  // Carrega os dados da planilha ao iniciar
  loadData();
});